# 引入你写的工具类
from EAD-CE import EAD_CE
# 引入你的基线模型
import BASE_MODEL

# 1. 准备数据并拟合你的基线模型
base_model = BASE_MODEL()
base_model.fit(X_train)

# 2. 实例化优化器 (自定义你想跑的迭代次数或CPU核心数)
optimizer = EAD_CE(max_iter=150, n_jobs=4, tol=0.005)

# 3.优化模型
feature_names = [f'feat_{i}' for i in range(X_train.shape[1])]
final_weights, optimized_model = optimizer.optimize(base_model, feature_names, verbose=True)

