import numpy as np
import copy
import warnings
from typing import Dict, List, Tuple, Any
from joblib import Parallel, delayed

warnings.filterwarnings("ignore")


class EAD_CE:
    """
    该工具类将反事实解释机制与模型优化完全解耦。它接收一个已初始化的异常检测模型，
    通过寻找决策边界附近样本的稀疏反事实微扰，动态优化并返回新的特征权重。

    【接口要求】传入的 baseline_model 必须实现以下接口：
      - .X_train: 模型训练时使用的特征矩阵 (numpy.ndarray)
      - .get_all_scores(): 返回所有训练样本的异常分数 (numpy.ndarray)
      - .score_one_with_weights(x_dict, feature_names): 接收单样本特征字典，返回分数 (float)
      - .update_weights(new_weights): 接收新的权重数组并更新模型内部权重
    """

    def __init__(self,
                 max_iter: int = 100,
                 tol: float = 0.01,
                 forget_factor: float = 0.4,
                 n_jobs: int = 1,
                 random_state: int = 42):
        """
        初始化优化器参数。

        参数:
        - max_iter: 最大优化迭代次数 (默认: 100)
        - tol: 提前停止的收敛容忍度 (默认: 0.01)
        - forget_factor: 动量更新的遗忘因子，值越大越保留历史权重 (默认: 0.4)
        - n_jobs: 并行计算的核心数，-1 表示使用所有核心 (默认: 1)
        - random_state: 随机种子，保证采样的可复现性 (默认: 42)
        """
        self.max_iter = max_iter
        self.tol = tol
        self.forget_factor = forget_factor
        self.n_jobs = n_jobs
        self.random_state = random_state

    @staticmethod
    def _calculate_separation_metric(scores: np.ndarray) -> float:
        """内部评估：计算正常样本与异常样本的分数分离度"""
        if len(scores) < 10: return 0.0
        threshold = np.percentile(scores, 90)
        scores_out = scores[scores >= threshold]
        scores_in = scores[scores < threshold]
        if len(scores_out) == 0 or len(scores_in) == 0: return 0.0
        return float((np.mean(scores_out) - np.mean(scores_in)) / (np.std(scores_in) + 1e-9))

    @staticmethod
    def _generate_cf_sparse(x: np.ndarray, detector: Any, target_score: float, X_normal_np: np.ndarray,
                            feature_names: List[str]):
        """核心步骤 1：为单个样本生成稀疏反事实微扰 """
        if len(X_normal_np) == 0: return None

        # 1. 寻找最近的正常样本作为方向先验
        dists = np.linalg.norm(X_normal_np - x, axis=1)
        x_nn = X_normal_np[np.argmin(dists)]
        x_nn_dict = {k: v for k, v in zip(feature_names, x_nn)}

        real_target = max(target_score, detector.score_one_with_weights(x_nn_dict, feature_names)) + 0.01
        full_diff = x_nn - x
        n_features = len(x)
        sorted_indices = np.argsort(np.abs(full_diff))[::-1]

        best_perturbation = None
        min_cost = float('inf')

        # 强制特征稀疏性搜索
        check_steps = sorted(
            list(set([k for k in [1, 2, 3, 5, 10, int(n_features / 2), n_features] if k <= n_features])))
        found_any = False

        for k in check_steps:
            direction = np.zeros_like(full_diff)
            direction[sorted_indices[:k]] = full_diff[sorted_indices[:k]]
            low, high, current_k_best_alpha = 0.0, 1.0, None

            # 二分搜索最优干预步长 (Alpha)
            for _ in range(8):
                mid = (low + high) / 2
                cand_dict = {name: val for name, val in zip(feature_names, x + mid * direction)}
                if detector.score_one_with_weights(cand_dict, feature_names) <= real_target:
                    current_k_best_alpha, high = mid, mid
                else:
                    low = mid

            if current_k_best_alpha is not None:
                found_any = True
                current_perturbation = np.abs(current_k_best_alpha * direction)
                current_cost = np.sum(current_perturbation)

                # 记录最小干预代价
                if current_cost < min_cost:
                    min_cost = current_cost
                    best_perturbation = current_perturbation

                if k <= 2 and current_k_best_alpha < 0.2:
                    break

        # 降级策略：如果稀疏搜索失败，采用全量特征微调
        if not found_any:
            low, high, best_alpha = 0.0, 1.0, None
            for _ in range(10):
                mid = (low + high) / 2
                cand_dict = {k: v for k, v in zip(feature_names, x + mid * full_diff)}
                if detector.score_one_with_weights(cand_dict, feature_names) <= real_target:
                    best_alpha, high = mid, mid
                else:
                    low = mid
            if best_alpha is not None:
                return {"perturbation": np.abs((x + best_alpha * full_diff) - x)}
            return None

        return {"perturbation": best_perturbation}

    @staticmethod
    def _extract_weights_from_cfs(counterfactuals: List[Dict], n_features: int) -> np.ndarray:
        """核心步骤 2：将反事实微扰总量转化为特征重要性权重"""
        total_perturb = np.zeros(n_features)
        valid_cf_count = 0
        for cf in counterfactuals:
            if cf is not None and "perturbation" in cf:
                total_perturb += cf["perturbation"]
                valid_cf_count += 1

        if valid_cf_count == 0 or total_perturb.sum() == 0:
            return np.ones(n_features)

        mean_perturb = total_perturb / valid_cf_count
        feature_weights = mean_perturb / (mean_perturb.sum() + 1e-12) * n_features
        # 截断以防止单一特征权重过大或过小导致模型崩溃
        return np.clip(feature_weights, 0.01, n_features / 2.0)

    @staticmethod
    def _smooth_weights(old_weights: np.ndarray, new_weights: np.ndarray, forget_factor: float) -> np.ndarray:
        """核心步骤 3：使用动量机制平滑更新权重"""
        n_features = len(old_weights)
        updated = forget_factor * old_weights + (1 - forget_factor) * new_weights
        return (updated / (updated.sum() + 1e-12)) * n_features


    def optimize(self, baseline_model: Any, feature_names: List[str], verbose: bool = True) -> Tuple[np.ndarray, Any]:
        """
        执行主优化循环。

        参数:
        - baseline_model: 已初始化并拟合(fit)过数据的基线模型对象
        - feature_names: 特征名称列表
        - verbose: 是否打印迭代日志

        返回:
        - current_w: 最终优化得到的特征权重数组
        - detector: 赋予了新权重并更新完成的模型
        """
        detector = copy.deepcopy(baseline_model)
        n_features = len(feature_names)
        current_w = np.ones(n_features)
        detector.update_weights(current_w)

        current_metric = self._calculate_separation_metric(detector.get_all_scores())

        if verbose:
            print(f"\n--- 启动反事实特征权重优化 (Features: {n_features}) ---")
            print(f"{'Iter':<5} | {'Separation Metric':<20} | {'Status'}")
            print("-" * 50)
            print(f"{'Init':<5} | {current_metric:<20.4f} | Base")

        for iteration in range(1, self.max_iter + 1):
            scores = detector.get_all_scores()
            threshold = np.percentile(scores, 90)

            # 定位需要进行反事实解释的决策边界样本
            ambiguous_mask = scores >= threshold
            suspect_indices = np.where(ambiguous_mask)[0]
            normal_mask = scores < threshold

            if len(suspect_indices) == 0 or not np.any(normal_mask):
                if verbose: print("  提前停止：未找到合适的决策边界样本。")
                break

            X_normal_np = detector.X_train[normal_mask]
            np.random.seed(self.random_state)
            sample_count = min(20, len(suspect_indices))
            sample_indices = np.random.choice(suspect_indices, sample_count, replace=False)
            target = np.mean(scores[normal_mask])

            # 并行计算反事实微扰
            cfs = Parallel(n_jobs=self.n_jobs, prefer="processes")(
                delayed(self._generate_cf_sparse)(detector.X_train[idx], detector, target, X_normal_np, feature_names)
                for idx in sample_indices
            )

            # 更新权重
            new_weights = self._extract_weights_from_cfs(cfs, n_features)
            new_w_candidate = self._smooth_weights(current_w, new_weights, self.forget_factor)

            temp_detector = copy.deepcopy(detector)
            temp_detector.update_weights(new_w_candidate)
            new_scores = temp_detector.get_all_scores()

            new_metric = self._calculate_separation_metric(new_scores)
            improvement = new_metric - current_metric

            status = "Update"
            if improvement < self.tol and iteration > 1:
                status = "Converged"
            elif improvement < 0 and iteration > 1:
                status = "Degraded"

            if verbose:
                print(f"{iteration:<5} | {new_metric:<20.4f} | {status} (Imp: {improvement:+.4f})")

            # 状态评估机制：只接受正向优化
            if improvement >= self.tol or iteration == 1:
                detector = temp_detector
                current_w = new_w_candidate
                current_metric = new_metric
            else:EAD-CE.py
                break

        return current_w, detector